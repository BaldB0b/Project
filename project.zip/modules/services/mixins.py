from django.contrib.auth.mixins import AccessMixin, UserPassesTestMixin
from django.contrib import messages
from django.shortcuts import redirect
from django.core.exceptions import PermissionDenied
from modules.system.models import Profile
from modules.journal.models import Lessons,StudentsGroup
import datetime
from django.contrib.auth.models import User


class AuthorRequiredMixin(AccessMixin):
    """Только для авторов."""
    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return self.handle_no_permission()
        if request.user.is_authenticated:
            if request.user != self.get_object().author or request.user.is_staff:
                messages.info(request, 'Изменение и удаление статьи доступно только автору')
                return redirect('home')
        return super().dispatch(request, *args, **kwargs)
    
    
class UserIsNotAuthenticated(UserPassesTestMixin):
    """Если авторизован то False."""
    def test_func(self):
        if self.request.user.is_authenticated:
            messages.info(self.request, 'Вы уже авторизованы. Вы не можете посетить эту страницу.')
            raise PermissionDenied
        return True
        
    def handle_no_permission(self):
        return redirect('home')
    
    
class UserIsAuthenticated(UserPassesTestMixin):
    """Если не авторизован то False."""
    def test_func(self):
        if not self.request.user.is_authenticated:
            messages.info(self.request, 'Войдите в аккаунт')
            raise PermissionDenied
        return True
        
    def handle_no_permission(self):
        return redirect('home')


class ManagerGroupRequiredMixin(UserPassesTestMixin):
    """Только для менеджера."""
    def test_func(self):
        if not self.request.user.is_authenticated or not self.request.user.groups.filter(name='Managers').exists():
            messages.info(self.request, 'Вы не авторизованы или у вас нет прав. Вы не можете посетить эту страницу.')
            raise PermissionDenied
        return True
    def handle_no_permission(self):
        return redirect('home')



class TeacherPermissionsMixin:
    """Суперпользователь или учитель(который имеет lessons в group) или менеджер."""
    def dispatch(self, request, *args, **kwargs):
        if not self.has_permissions():
            raise PermissionDenied()
        return super().dispatch(request, *args, **kwargs)
    def has_permissions(self):
        if self.request.method == 'POST':
            group_id = self.request.POST.get('group')
        else:
            group_id = self.kwargs['pk']
        teacher = Profile.objects.prefetch_related('group').filter(user=self.request.user, lessons__studentsgroup__id=group_id, ).exists()
        
        return self.request.user.is_superuser or teacher or self.request.user.groups.filter(name='Managers')   
    
    
class GroupManagerMixin(TeacherPermissionsMixin):
    """Учитель который является классным руководителем."""
    def has_permissions(self):
        if self.request.method == 'POST':
            group_id = self.request.POST.get('group')
        else:
            group_id = self.kwargs['pk']
        group_manager = Profile.objects.prefetch_related('group').filter(user=self.request.user, group_manager=group_id, ).exists()
        teacher = Profile.objects.prefetch_related('group').filter(user=self.request.user, lessons__studentsgroup__id=group_id, ).exists()
        
        return group_manager or teacher or self.request.user.is_superuser or self.request.user.groups.filter(name='Managers')
    
    
class TeacherLessonPermissionsMixin(TeacherPermissionsMixin):
    """Учитель который является преподователем предмета."""
    def has_permissions(self):
        if self.request.method == 'POST':
            lessons_id = self.request.POST.get('lessons')
        else:
            lessons_id = self.kwargs['lessons_id']
        teacher = Profile.objects.prefetch_related('lessons').filter(user=self.request.user, lessons=lessons_id).exists()
       
        return teacher or self.request.user.is_superuser or self.request.user.groups.filter(name='Managers')


class ScoreJournalMixin:
    def create_date_period_list(self):
        """Список дат находящихся между датой начала и окончания."""
        day_delta = datetime.timedelta(days=1)
        try:
            start_date = datetime.datetime.strptime(self.request.GET.get('start-date'), '%Y-%m-%d').date()
            end_date = datetime.datetime.strptime(self.request.GET.get('end-date'), '%Y-%m-%d').date()
        except (ValueError, TypeError):
            end_date = datetime.date.today()
            start_date = end_date - datetime.timedelta(days=15)
        return [start_date + i * day_delta for i in range((end_date - start_date).days + 1)]

    @staticmethod    
    def create_scores_dict(date_period, scores, grouping_object, grouping_object_name):
        """Колекция где ключи дата и id студента в которую записывается оценка и её id."""
        scores_dict = {}
        for date in date_period:
            scores_dict[date] = {}
            for obj in grouping_object:
                scores_dict[date][obj.id] = (0, 0)
                if scores:
                    for score in scores:
                        if obj.id == score[grouping_object_name] and date == score['created']:
                            scores_dict[date][obj.id] = (score['value'], score['id'])
                            break
        return scores_dict
    
    


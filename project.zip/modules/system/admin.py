from django.contrib import admin

from .models import Profile

admin.site.site_header = "Электронный журнал"
admin.site.site_title = "Панель администрирования"
admin.site.index_title = "Добро пожаловать в админку"

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):   
    """
    Админ-панель модели профиля
    """
    list_display = ('user', 'birth_date', 'slug')
    list_display_links = ('user', 'slug')

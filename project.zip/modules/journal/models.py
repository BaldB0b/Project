from django.db import models
from modules.services.utils import unique_slugify
from django.contrib.auth import get_user_model
from django.urls import reverse,reverse_lazy
User = get_user_model()

class Lessons(models.Model):
       fullname = models.CharField('Полное наименование', max_length=100)
       title = models.CharField('Заголовок', max_length=100)
       class Meta:
              verbose_name = 'Урок'
              verbose_name_plural = 'Уроки'
       def __str__(self):
              return f'Предмет: {self.title} '

class StudentsGroup(models.Model):
       fullname = models.CharField('Полное наименование',max_length=100)
       title = models.CharField('Заголовок',max_length=100)
       updated = models.DateField('Дата обновления', auto_now=True)
       created = models.DateField('Дата создания', auto_now_add=True)
       lessons = models.ManyToManyField(Lessons, verbose_name='Предметы группы',help_text="Для выбора нескольких надо зажать клавишу CTRL и кликать поочерёдно")
       class Meta:
              verbose_name = 'Группа'
              verbose_name_plural = 'Группы'
       def __str__(self):
              return f'Группа: {self.title} '
       
       def get_absolute_url(self):
              return reverse_lazy('group_student_detail', kwargs={'pk': self.pk})
       
       
class Students(models.Model):
       surname = models.CharField('Фамилия',max_length=100, null=True, blank=True)
       name = models.CharField('Имя',max_length=100, null=True, blank=True)
       patronymic = models.CharField('Отчество',max_length=100, null=True, blank=True)
       group = models.ForeignKey(StudentsGroup, on_delete=models.CASCADE)
       birthday = models.DateField('Дата рождения',null=True, blank=True)
       
       GENDER_CHOOSE = (
        ('m', 'Мужчина'),
        ('w', 'Женщина'),
    )
       gender = models.CharField(
        max_length=1, choices=GENDER_CHOOSE, blank=True, null=True)
       
       updated = models.DateField('Дата обновления', auto_now=True)
       created = models.DateField('Дата создания', auto_now_add=True)
       
       class Meta:
              verbose_name = 'Студент'
              verbose_name_plural = 'Студенты'
       
       def __str__(self):
              return f'Имя: {self.name} Отчество: {self.surname}  Группа: {self.group.title} '
       

class Grade(models.Model):
       student = models.ForeignKey(Students, on_delete=models.SET_NULL,null=True,)
       subject = models.ForeignKey(Lessons, on_delete=models.SET_NULL,null=True,)
       group = models.ForeignKey(StudentsGroup, on_delete=models.CASCADE, verbose_name='Наименование класса')
       teacher = models.ForeignKey(User, related_name='score_teacher', on_delete=models.SET_NULL,null=True, verbose_name='Учитель')
       
       VALUE_CHOICES = [("5", '5'), ("4", '4'), ("3", '3'), ("2", '2'), ("0", '-'),("НБ",'НБ')]
       
       value = models.CharField(max_length=2, choices=VALUE_CHOICES, verbose_name='Оценка')
       created = models.DateField(verbose_name='Дата создания')
       updated = models.DateTimeField(auto_now=True, verbose_name='Дата обновления')
      
       class Meta:
              verbose_name='Оценку'
              verbose_name_plural='Оценки'
       def __str__(self):
              return f'Оценка: {self.value} Студент: {self.student.name} {self.student.surname} Дата: {self.created}'
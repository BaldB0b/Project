from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.models import User
from django.views.generic.edit import CreateView, FormView
from modules.journal.forms import addStudents, addStudentsGroup, addLessons,GradeForm, editStudents
from ..services.mixins import UserIsNotAuthenticated, ManagerGroupRequiredMixin, TeacherPermissionsMixin, TeacherLessonPermissionsMixin, ScoreJournalMixin,UserIsAuthenticated, GroupManagerMixin
from django.db import transaction
from django.shortcuts import render, get_object_or_404, redirect,render, redirect
from django.views import View
from modules.journal.models import Students,StudentsGroup, Lessons, Grade
from django.views.generic import ListView, DetailView, UpdateView, DeleteView
from modules.system.models import Profile
from django.views.generic.base import View
from django.http import JsonResponse
from django.urls import reverse_lazy


def student_list(request):
    students = Students.objects.all()
    return render(request, 'journal/students/list_students.html', {'students': students})

class StudentCreate(ManagerGroupRequiredMixin, CreateView):
    model = Students
    form_class = addStudents
    template_name = 'journal/students/add_student.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Добавить студента'
        return context
    
    def get_success_url(self):
        return reverse_lazy('group_student_detail', kwargs={'pk': self.object.group.id})
    

class EditStudent(ManagerGroupRequiredMixin, UpdateView):
    model=Students
    form_class = editStudents
    template_name = 'journal/students/edit_student.html'
    def get_success_url(self):
        return reverse_lazy('group_student_detail', kwargs={'pk': self.object.group.id})
    
class DeleteStudent(ManagerGroupRequiredMixin, DeleteView):
    model = Students
    template_name = 'journal/students/delete_student.html'
    def get_success_url(self):
        return reverse_lazy('group_student_detail', kwargs={'pk': self.object.group.id})
   
class StudentGroupCreate(ManagerGroupRequiredMixin, CreateView):
    model = StudentsGroup
    form_class = addStudentsGroup  
    template_name = 'journal/add_studentgroup.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Добавить группу'
        return context
    
    def form_valid(self, form):        
        form.save()
        return redirect('add_studentgroup')
    
    
class LessonsCreate(ManagerGroupRequiredMixin, CreateView):
    model = Lessons
    form_class = addLessons
    template_name = 'journal/add_lessons.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Добавить предмет(урок)'
        return context
    
    def form_valid(self, form):        
        form.save()
        #return redirect('select_profile')
        return redirect('add_lessons')
    

class GroupStudentListView(UserIsAuthenticated, ListView):
    """Список групп в учебном заведении."""
    template_name = 'journal/group_list.html'
    context_object_name = 'users_teachers'
    
    def get_queryset(self):
        queryset = Profile.objects.prefetch_related('lessons').filter(user__groups__name="Teachers")&Profile.objects.exclude(group_manager=None)&Profile.objects.exclude(user__is_superuser=True)&Profile.objects.exclude(user__groups__name='Managers')&Profile.objects.exclude(user__is_staff=True)
        return queryset


class GroupStudentDetailView(TeacherPermissionsMixin, UserIsAuthenticated , DetailView):
    """Информация о конкретной группе."""
    model = StudentsGroup
    template_name = 'journal/group_detail.html'
    context_object_name = 'group'

    def get_context_data(self, **kwargs):        
        context = super(GroupStudentDetailView, self).get_context_data()
        context['students'] = Students.objects.all().filter(group_id=self.kwargs['pk'])    
        context['title'] = f'Журнал группы: {self.object.title}' 
        return context
    
    
class GradeLessonListView(TeacherLessonPermissionsMixin, ListView, ScoreJournalMixin):
    """Журнал оценок класса по предмету."""
    template_name = 'journal/journal_lesson_list.html'
    context_object_name = 'scores'
    permission_denied_message = 'В доступе отказанно'

    def get_queryset(self):
        group_student = StudentsGroup.objects.all()
        self.group = get_object_or_404(group_student, id=self.kwargs['group_id'])
        self.lessons = get_object_or_404(Lessons, id=self.kwargs['lessons_id'])
        queryset = Grade.objects.select_related('group', 'lessons')\
            .filter(group_id=self.kwargs['group_id'], subject_id=self.kwargs['lessons_id'])
        return queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super(GradeLessonListView, self).get_context_data(**kwargs)
        date_period = self.create_date_period_list()
        students = Students.objects.select_related('group').filter(group=self.group)
        scores = Grade.objects.select_related('group', 'lessons').filter(created__in=date_period, subject_id=self.lessons, group_id=self.group)
        context['date_period'] = date_period
        context['students'] = students
        context['scores_dict'] = self.create_scores_dict(date_period,scores.values('id', 'student', 'value', 'created'),students, 'student')
        context['group'] = self.group
        context['lessons'] = self.lessons
        return context       
    

class AddGradeView(View,TeacherLessonPermissionsMixin):
    def get(self, request, group_id, lessons_id, student_id):
        group = StudentsGroup.objects.get(id=group_id)
        lessons = Lessons.objects.get(id=lessons_id)
        student = Students.objects.get(id=student_id)
        form = GradeForm(initial={'group': group, 'subject': lessons, 'student': student})
        return render(request, 'journal/add_grade.html', {'form': form,'group':group,'lessons':lessons,'student':student})
    
    def post(self, request, group_id, lessons_id, student_id):
        form = GradeForm(request.POST)
        if form.is_valid():
            grade = form.save(commit=False)
            grade.group_id = group_id
            grade.subject_id = lessons_id
            grade.student_id = student_id
            grade.teacher=request.user
            grades = Grade.objects.filter(group=grade.group, subject=grade.subject, student=grade.student, created=grade.created)            
            if grades.exists():
                grade = grades.first()
                grade.value = form.cleaned_data['value']
                grade.save()
            else:
                grade.save()
            return redirect('score_lesson', group_id=group_id, lessons_id=lessons_id)
        else:
            return render(request, 'journal/add_grade.html', {'form': form})
  

@login_required
def index(request):    
    context={'title':'Главная страница'}
    return render(request, 'home.html', context)

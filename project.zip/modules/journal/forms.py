from django import forms
from django.contrib.auth.models import User
from django.forms import ModelForm

from .models import Students,StudentsGroup,Lessons,Grade


class addStudents(ModelForm):
      class Meta:
        model = Students
        fields = ['surname', 'name', 'patronymic', 'group', 'birthday', 'gender',]
        widgets = {
          'birthday': forms.DateInput(attrs={'placeholder': 'Дата рождения', 'type': 'date'}),
          }
      def __init__(self, *args, **kwargs):
        """
        Обновление стилей формы под bootstrap
        """
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'field-regstudent',
                'autocomplete': 'off'
            })
            
            
            
class editStudents(ModelForm):
      class Meta:
        model = Students
        fields = ['surname', 'name', 'patronymic', 'group', 'birthday', 'gender',]
        widgets = {
          'birthday': forms.DateInput(attrs={'placeholder': 'Дата рождения', 'type': 'date'}),
          }
      def __init__(self, *args, **kwargs):
        """
        Обновление стилей формы под bootstrap
        """
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control',
                'autocomplete': 'off'
            })
          
class addStudentsGroup(ModelForm):
      class Meta:
        model = StudentsGroup
        fields = ['fullname', 'title','lessons']
      def __init__(self, *args, **kwargs):
        """
        Обновление стилей формы под bootstrap
        """
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control',
                'autocomplete': 'off'
            })


class addLessons(ModelForm):
      class Meta:
        model = Lessons
        fields = ['fullname', 'title']
      def __init__(self, *args, **kwargs):
        """
        Обновление стилей формы под bootstrap
        """
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control',
                'autocomplete': 'off'
            })
            
            
############## Часть для работы с оценками

class GradeForm(forms.ModelForm):
    class Meta:
        model = Grade
        fields = ['value', 'created']
        widgets = {
            'created': forms.DateInput(attrs={'type': 'date'}),
        }
    def __init__(self, *args, **kwargs):
        """
        Обновление стилей формы под bootstrap
        """
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control',
                'autocomplete': 'off',
            })

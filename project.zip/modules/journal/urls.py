from django.urls import path, include
from . import views
from django.urls import path
from .views import  StudentCreate, StudentGroupCreate, LessonsCreate
from .views import  GroupStudentListView, GroupStudentDetailView, GradeLessonListView, AddGradeView, EditStudent, DeleteStudent, student_list


urlpatterns = [
    path('', views.index, name='home'),    
    path('journal/students/', student_list, name='student_list'),
    path('journal/add_student/', StudentCreate.as_view(), name='add_student'), 
    path('journal/edit_student/<int:pk>/', EditStudent.as_view(), name='edit_student'), 
    path('journal/delete/<int:pk>/', DeleteStudent.as_view(), name='delete_student'),
    path('journal/add_studentgroup/', StudentGroupCreate.as_view(), name='add_studentgroup'), 
    path('journal/add_lessons/', LessonsCreate.as_view(), name='add_lessons'), 
    path('journal/', GroupStudentListView.as_view(), name='group_student_list'),
    path('journal/<int:pk>/', GroupStudentDetailView.as_view(), name='group_student_detail'),
    path('journal/<int:group_id>/<int:lessons_id>/', GradeLessonListView.as_view(), name='score_lesson'),
    path('add_grade/<int:group_id>/<int:lessons_id>/<int:student_id>/', AddGradeView.as_view(), name='add_grade'),
    ]